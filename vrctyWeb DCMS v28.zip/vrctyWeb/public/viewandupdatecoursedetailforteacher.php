<?php require_once("../includes/functions.php"); ?>
<?php
session_start();

if (!logedin()) {

    header("Location: index.php?valid=notlogedin");
    exit();
}
if (isset($_SESSION['address'])) {
    if ($_SESSION['address'] != "teacher.php") {
        redirect_to($_SESSION['id']);
    }
}

if (isset($_GET['id'])) {
    $userteacher1 = $_GET['id'];
} else {
    redirect_to("index.php");
}

if (isset($_GET['emid'])) {
    $teacheremid1 = $_GET['emid'];
} else {
    redirect_to("index.php");
}


$semestercode = semestercode();
?>

<?php
$usmsg=$updatecc="";
if (isset($_GET['us'])) {
    $updatestatus = $_GET['us'];
    if (isset($_GET['cc'])) {
        $updatecc = $_GET['cc'];
    }

    if ($updatestatus=="success"){
      $usmsg="<span style='color: green;'>update success</span>";
    }elseif ($updatestatus=="same"){
        $usmsg="<span style='color: red;'>same info need not to update</span>";
    }elseif ($updatestatus=="empty"){
        $usmsg="<span style='color: red;'>field can not be empty</span>";
    }
    else{
        $usmsg="<span style='color: red;'>update faild</span>";
    }
}





?>



<?php require_once("../includes/db_connection.php"); ?>

<?php
//$getteacheremid1query1 = "select emid from users where id={$userteacher};";
//$getteacheremid1 = mysqli_query($connection, $getteacheremid1query1);
//while ($inforow1 = mysqli_fetch_assoc($getteacheremid1)) {
//    $teacheremid1 = $inforow1['emid'];
//}
//
//?>


<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" href="styleadmin.css"/>
</head>
<body>
<ul class="nav">
    <div class="logo">Teacher Panal (<?php echo $semestercode ?>)</div>

    <li><a href="<?php echo $_SESSION['id'] ?>">Home</li>
    <li><a href="offeredcourseforteacher.php?id=<?php echo $_GET['id'] ?>">Offered course</li>
    <li>
        <a href="viewandupdatecoursedetailforteacher.php?emid=<?php echo $teacheremid1 ?>&id=<?php echo $userteacher1 ?>">Course
            Details</li>
    <li><a href="logout.php">Logout</a></li>

</ul>

<!--detail section-->
<!--<fieldset style="align:'center';">-->
<!--    <legend>Teacher Details</legend>-->


<!--    --><?php
//
//    //colection profile info
//
//    $collectInfoquery = "SELECT title,firstname,lastname,initial,department,faculty,campus,mode,designation,emid,email,mobile FROM users WHERE emid={$teacheremid1};";
//    $collectInfoqueryresult = mysqli_query($connection, $collectInfoquery);
//    while ($collectInforow = mysqli_fetch_assoc($collectInfoqueryresult)) {
//        $tctitle = $collectInforow['title'];
//        $tcfirstname = $collectInforow['firstname'];
//        $tclastname = $collectInforow['lastname'];
//        $tcinitial = $collectInforow['initial'];
//        $tcdepartment = $collectInforow['department'];
//        $tcfaculty = $collectInforow['faculty'];
//        $tccampus = $collectInforow['campus'];
//        $tcmode = $collectInforow['mode'];
//        $tcdesignation = $collectInforow['designation'];
//        $tcemid = $collectInforow['emid'];
//        $tcmobile = $collectInforow['mobile'];
//        $tcemail = $collectInforow['email'];
//    }
//
//    echo "<p>{$tctitle} {$tcfirstname} {$tclastname} ({$tcinitial}) <br />
// {$tcdesignation} Dept. of {$tcdepartment} , {$tcfaculty} <br>
//  {$tcmode} , {$tccampus} <br>
//  Employe ID : {$tcemid}<br>
//  E-mail : {$tcemail}<br>
//  Phone : {$tcmobile}</p> ";
//
//

echo "<h3 style='color: green;'>$usmsg  {$updatecc}</h3>";

?>
    <fieldset>
        <legend><h3>Course Details</h3></legend>

        <?php

        $courseInfoquery = "select * from takencourses WHERE emid='{$teacheremid1}'";
        $courseInforesult = mysqli_query($connection, $courseInfoquery);
        while ($courseInforow = mysqli_fetch_assoc($courseInforesult)) {
            $depttaken = $courseInforow['dept'];
            $leveltermtaken = $courseInforow['levelterm'];
            $courseCodetaken = $courseInforow['coursecode'];
            $coursetitletaken = $courseInforow['coursetitle'];
            $sectiontaken = $courseInforow['section'];
            $credithourtaken = $courseInforow['credithour'];
            $crnametaken = $courseInforow['crname'];
            $cridtaken = $courseInforow['crid'];
            $cremailtaken = $courseInforow['cremail'];
            $crnumtaken = $courseInforow['crnum'];
            $totalstudenttaken = $courseInforow['totalstudent'];
            $regstudenttaken = $courseInforow['regstudent'];
            $semestercodetaken = $courseInforow['semestercode'];

            echo "
<form action='action_c_i_u_forteacher.php?id={$userteacher1}&emid={$teacheremid1}&cc={$courseCodetaken}' method='post' >
<fieldset>
<legend><b> {$courseCodetaken} : {$coursetitletaken}  ({$credithourtaken} Credits) {$semestercodetaken}</b></legend>
<b><u>LEVEL&TERM</u> :</b> {$leveltermtaken} &emsp;&emsp;
<b><u>SECTION</u> : </b>   {$sectiontaken} &emsp;&emsp;
<b><u>Total Student</u> : </b> <input type='text' value='{$totalstudenttaken}' name='totalstudent' size='3'>  &emsp;&emsp;
<b><u>Registered Student</u> : </b> <input type='text' value='{$regstudenttaken}' name='regstudent' size='3'>  &emsp;&emsp; <br><br>
<b><u>CR name</u> : </b> <input type='text' value='{$crnametaken}' name='crname' size='30'>   &emsp;&emsp;
<b><u>CR ID</u> : </b> <input type='text' value='{$cridtaken}' name='crid' size='30'>   &emsp;&emsp;<br>
<b><u>CR e-mail</u> : </b> <input type='text' value='{$cremailtaken}' name='cremail' size='30'>  &emsp;&emsp;
<b><u>CR phone</u> : </b> <input type='text' value='{$crnumtaken}' name='crphone' size='30'>   &emsp;&emsp;<br>
 &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
  &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
  <input type='submit' value='UPDATE' >  
</fieldset><br></form>";
        }










        ?>
    </fieldset>

<!--</fieldset>-->


</body>
</html>


<?php
//$toralstudentupdate=$totalstudenttaken;
//$regstudentupdate=$regstudenttaken;
//$crnameupdate=$crnametaken;
//$cridupdate=$cridtaken;
//$cremailupdate=$cremailtaken;
//$crphoneupdata=$crnumtaken;
//
//if ($_SERVER['REQUEST_METHOD']=='POST'){
//    if (!empty($_POST['totalstudent'])){
//        $toralstudentupdate=$_POST['totalstudent'];
//        $toralstudentupdatequery="update takencourses set totalstudent='{$toralstudentupdate}' WHERE emid='{$teacheremid1}' AND coursecode='{$courseCodetaken}' limit 1";
//        mysqli_query($connection,$toralstudentupdatequery);
//    }
//    if (!empty($_POST['regstudent'])){
//        $regstudentupdate=$_POST['regstudent'];
//    }
//    if (!empty($_POST['crname'])){
//        $crnameupdate=$_POST['crname'];
//    }
//    if (!empty($_POST['crid'])){
//        $cridupdate=$_POST['crid'];
//    }
//    if (!empty($_POST['cremail'])){
//        $cremailupdate=$_POST['cremail'];
//    }
//    if (!empty($_POST['crphone'])){
//        $crphoneupdata=$_POST['crphone'];
//    }
//
//
//}






?>