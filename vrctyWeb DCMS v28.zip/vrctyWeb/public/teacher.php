<?php require_once ("../includes/functions.php"); ?>
<?php
session_start();

if(!logedin()){
    
    header("Location: index.php?valid=notlogedin");
    exit();
}
if(isset($_SESSION['address'])){    
    if($_SESSION['address']!="teacher.php"){
        redirect_to($_SESSION['id']);
}
}
if (isset($_GET['id'])){
    $userteacher=$_GET['id'];
}else{
    redirect_to("index.php");
}
$semestercode= semestercode();
?>
<?php require_once("../includes/db_connection.php"); ?>
<?php
$getteacheremid1query2 = "select emid from users where id={$userteacher};";
$getteacheremid2 = mysqli_query($connection, $getteacheremid1query2);
while ($inforow2 = mysqli_fetch_assoc($getteacheremid2)) {
    $teacheremid2 = $inforow2['emid'];
}

?>


<!DOCTYPE html>
<html>
<head>
 <title></title>
 <link rel="stylesheet" href="styleadmin.css"/>
</head>
<body>
  <ul class="nav">
    <div class="logo">Teacher Panal (<?php echo $semestercode ?>)</div>

    <li><a href="<?php echo $_SESSION['id']?>">Home</li>
    <li><a href="offeredcourseforteacher.php?id=<?php echo $_GET['id']?>">Offered course</li>
      <li><a href="viewandupdatecoursedetailforteacher.php?emid=<?php echo $teacheremid2?>&id=<?php echo $userteacher ?>">Course Details</li>
    <li><a href="logout.php">Logout</a></li>

  </ul>




  <?php

  //colection profile info

  $collectInfoquery = "SELECT title,firstname,lastname,initial,department,faculty,campus,mode,designation,emid,email,mobile FROM users WHERE id={$userteacher};";
  $collectInfoqueryresult = mysqli_query($connection, $collectInfoquery);
  while ($collectInforow = mysqli_fetch_assoc($collectInfoqueryresult)) {
      $tctitle = $collectInforow['title'];
      $tcfirstname = $collectInforow['firstname'];
      $tclastname = $collectInforow['lastname'];
      $tcinitial = $collectInforow['initial'];
      $tcdepartment = $collectInforow['department'];
      $tcfaculty = $collectInforow['faculty'];
      $tccampus = $collectInforow['campus'];
      $tcmode = $collectInforow['mode'];
      $tcdesignation = $collectInforow['designation'];
      $tcemid = $collectInforow['emid'];
      $tcmobile = $collectInforow['mobile'];
      $tcemail = $collectInforow['email'];
  }

  $imgquery="select imgpath from photo WHERE emid='{$tcemid}'";
  $imgrslt=mysqli_query($connection,$imgquery);
  while ($imgrow=mysqli_fetch_assoc($imgrslt)){
      $img=$imgrow['imgpath'];
  }

  echo "

<p><img src=\"{$img}\"  style=\"width:304px;height:228px;\"></p>

<p>{$tctitle} {$tcfirstname} {$tclastname} ({$tcinitial}) <br />
 {$tcdesignation} Dept. of {$tcdepartment} , {$tcfaculty} <br>
  {$tcmode} , {$tccampus} <br>
  Employe ID : {$tcemid}<br>
  E-mail : {$tcemail}<br>
  Phone : {$tcmobile}</p> ";

  ?>








    </body>



    </html>
